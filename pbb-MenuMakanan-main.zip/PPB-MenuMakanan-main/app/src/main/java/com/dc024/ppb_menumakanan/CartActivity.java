package com.dc024.ppb_menumakanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class CartActivity extends AppCompatActivity {

    private TextView tvtotal;
    private Button btnSubmit;
    Bundle bundle;
    int finalPrice = 0;
    private RecyclerView recyclerView;
    AdapterCart adapterCart;
    private ArrayList<ModelMenuMakanan> modelMenuMakanan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        recyclerView = findViewById(R.id.rv_list_cart);
        tvtotal = findViewById(R.id.tv_total);

        btnSubmit = findViewById(R.id.btn_submitCart);

        bundle = getIntent().getExtras();

        if (bundle != null) {
            modelMenuMakanan = new ArrayList<>();
            modelMenuMakanan = (ArrayList<ModelMenuMakanan>) getIntent().getSerializableExtra("productArray");
            addData();
            hitung();
        }
    }

    private void addData() {
        adapterCart = new AdapterCart(CartActivity.this, modelMenuMakanan);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapterCart);
    }

    public void hitung() {
        modelMenuMakanan = new ArrayList<>();
        modelMenuMakanan = (ArrayList<ModelMenuMakanan>) getIntent().getSerializableExtra("productArray");
        for (int i = 0; i < modelMenuMakanan.size(); i++) {
            finalPrice += modelMenuMakanan.get(i).getiAmount() * modelMenuMakanan.get(i).getiPrice();
        }
        tvtotal.setText("Rp. " + finalPrice);
    }
}