package com.dc024.ppb_menumakanan;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements Serializable {

    final static int PRODUCT_REQUEST = 100;
    final static int PRODUCT_RESULT = 101;
    private RecyclerView rvMenuMakanan;

    private final ArrayList<ModelMenuMakanan> listCart = new ArrayList<>();
    int count;

    private ArrayList<ModelMenuMakanan> productArray;
    private AdapterMenuMakanan adapter;
    TextView tvCount;
    ImageView ivC;
    Boolean exist = false;

    private Button btGrid, btList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvMenuMakanan = findViewById(R.id.rvMenuMakanan);
        tvCount = findViewById(R.id.tv_countItem);
        ivC = findViewById(R.id.iv_count);
        btGrid = findViewById(R.id.btGrid);
        btList = findViewById(R.id.btList);


        ivC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<ModelMenuMakanan> productArray = new ArrayList<>();

                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        for (int i = 0; i < listCart.size(); i++) {
                            if (listCart.get(i).getiAmount() > 0) {
                                productArray.add(listCart.get(i));
                                exist = true;
                            }
                        }
                    }
                };
                runnable.run();
                if (exist) {
                    Intent intent = new Intent(MainActivity.this, CartActivity.class);
                    intent.putExtra("productArray", productArray);
                    Log.d("productArray", productArray.toString());
                    startActivityForResult(intent, PRODUCT_REQUEST);
                }
            }
        });

        initData();
        btGrid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isSwitched = adapter.toggleItemViewType();
                rvMenuMakanan.setLayoutManager(isSwitched ? new LinearLayoutManager(MainActivity.this) : new GridLayoutManager(MainActivity.this, 2));
                adapter.notifyDataSetChanged();
            }
        });

        btList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isSwitched = adapter.toggleItemViewType();
                rvMenuMakanan.setLayoutManager(isSwitched ? new LinearLayoutManager(MainActivity.this) : new GridLayoutManager(MainActivity.this, 2));
                adapter.notifyDataSetChanged();
            }
        });


    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == PRODUCT_RESULT) {
//            String total = data.getStringExtra("total");
//            String nama = data.getStringExtra("nama");
            productArray = new ArrayList<>();
            productArray = (ArrayList<ModelMenuMakanan>) data.getSerializableExtra("productArray");

            Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    for (int i = 0; i < listCart.size(); i++) {
                        listCart.get(i).setiAmount(0);
                        for (int j = 0; j < productArray.size(); j++) {
                            if (listCart.get(i).getNama().equals(productArray.get(j).getNama())) {
                                listCart.get(i).setiAmount(productArray.get(j).getiAmount());
                            }
                        }
                    }
                }
            };
            runnable.run();
            adapter.notifyDataSetChanged();
        }
    }

    public void  showProducts() {
        rvMenuMakanan.setLayoutManager(new LinearLayoutManager(MainActivity.this));
//        rvMenuMakanan.setLayoutManager(new GridLayoutManager(this,2));
        adapter = new AdapterMenuMakanan(MainActivity.this, listCart);
        rvMenuMakanan.setAdapter(adapter);

        adapter.setOnItemClickListener(new AdapterMenuMakanan.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
//                count++;
//                tvCount.setText("" + count);
            }
        });
    }

    private void initData(){
        listCart.add(new ModelMenuMakanan("Rendang",
                "Grobogan",
                "Makanan Terenak Di Nasi Padang",
                R.drawable.rendang,
                0,
                0,
                1000));

        listCart.add(new ModelMenuMakanan("Kalio",
                "Probolinggo",
                "Sebuah Menu yang Menyegarkan",
                R.drawable.kalio,
                1,
                0,
                2000));

        listCart.add(new ModelMenuMakanan("Dendeng Batok",
                "Brebes",
                "Mantep Pokok e",
                R.drawable.dendengbatok,
                2,
                0,
                3000));

        listCart.add(new ModelMenuMakanan("Gulai Tunjang",
                "Semarang",
                "Wenak tenan",
                R.drawable.gulaitunjang,
                3,
                0,
                4000));

        showProducts();
    }
}